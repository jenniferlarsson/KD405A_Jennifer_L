package se.mah.ke.jenniferlarsson;

public class Constants {
	public static final int MIN_LETTER= 3;
}
