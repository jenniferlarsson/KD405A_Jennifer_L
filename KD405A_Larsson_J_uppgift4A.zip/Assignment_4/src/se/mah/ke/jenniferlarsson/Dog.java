package se.mah.ke.jenniferlarsson;

/** A dog class, only contains a name **/
public class Dog {

	public String name;
	
	public Dog(String name) {
		this.name = name;		
	} 
}
